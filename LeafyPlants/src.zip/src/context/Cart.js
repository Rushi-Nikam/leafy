import React from 'react';

// Create the context
const cartContext = React.createContext();

// Export the context
export default { cartContext };
