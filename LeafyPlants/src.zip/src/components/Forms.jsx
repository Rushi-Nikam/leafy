import React, { useState } from "react";

import { useNavigate } from "react-router-dom";

import FormValidation from "./Validations/FormValidation";
import axios from "axios";

const Forms = () => {
  const navigate = useNavigate();
  const [values, setValues] = useState({
    name: "",
    number: "",
    email: "",
    Address:"",
    Gardenservice: "",
  });

  const [errors, setErrors] = useState({});
  const handleInput = (event) => {
    setValues((prev) => ({
      ...prev,
      [event.target.name]: [event.target.value],
    }));
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    setErrors(FormValidation(values));
    // if ( errors.name === "" && errors.number === "" && errors.email === "" && errors.Gardenservice === ""  ) {
      axios
        .post("http://localhost:8080/Forms", values)
        .then((res) => {
          navigate("/Show");
          // console.log(res);
        })
        .catch((err) => {
          console.error(err);
        });
    }
  // };
  return (
    <>
      <div className="bg-[#f0ebf8] grid justify-center w-full items-center">
        <form
          action=""
          method="POST" 
          className="border-2 my-8 rounded-md bg-white "
          onSubmit={handleSubmit}
        >
          <h1 className="text-2xl items-center mx-12 mt-12 uppercase font-medium">
            Leafy GARDEN SERVICE
          </h1>
          <div className=" flex  flex-col my-10 border-2 rounded-xl   mx-10 ">
            <label className="mx-10 mt-4 font-bold" htmlFor="name">
              Name:
            </label>
            <br />
            <input
              type="text"
              className=" w-96 h-12 rounded-lg border-none mx-10 outline-none text-lg "
              name="name"
              placeholder="Your answer"
              autoComplete="off"
              onChange={handleInput}
            />
          </div>
          {errors.name && (
            <span className="text-red-500 text-sm">{errors.name}</span>
          )}
          <div className="flex  flex-col my-10 border-2 rounded-xl   mx-10 ">
            <label className="mx-10 mt-4 font-bold" htmlFor="number">
              Number:
            </label>
            <br />
            <input
              type="tel"
              className=" w-96 h-12 rounded-lg border-none mx-10  outline-none text-lg"
              name="number"
              placeholder="Your Number"
              autoComplete="off"
              onChange={handleInput}
              />
            {errors.number && (
              <span className="text-red-500 text-sm">{errors.number}</span>
            )}
          </div>

          <div className="flex  flex-col my-10 border-2 rounded-xl   mx-10 ">
            <label className="mx-10 mt-4 font-bold" htmlFor="email">
              Email:
            </label>
            <br />
            {errors.email && (
              <span className="text-red-500 text-sm">{errors.email}</span>
            )}

            <input
              className=" w-96 h-12 rounded-lg border-none mx-10  outline-none text-lg "
              type="email"
              name="email"
              placeholder="Your email"
              autoComplete="off"
              onChange={handleInput}
              />
          </div>
          <div className="flex  flex-col my-10 border-2 rounded-xl   mx-10 ">
            <label className="mx-10 mt-4 font-bold" htmlFor="Address">
              Address:
            </label>
            <br />
         

            <input
              className=" w-96 h-12 rounded-lg border-none mx-10  outline-none text-lg "
              type="text"
              name="Address"
              autoComplete="off"
              onChange={handleInput}
              placeholder="Your Address"
              />
          </div>
              {errors.Address && (
                <span className="text-red-500 text-sm">{errors.Address}</span>
              )}

          <div className="flex  flex-col my-10 border-2 rounded-xl gap-4   mx-10 ">
            <label
              htmlFor="Gardenservice"
              className="uppercase font-bold mx-10"
            >
              Services Available
            </label>
            <div className="mx-10">
              <div> Single Day Maintenance Services</div>
              <div> monthly Maintenance Services</div>
              <div> Flower Garden Setup</div>
            </div>
            <input
              type="text"
              className=" w-96 h-12 rounded-lg border-none mx-10 outline-none text-lg "
              name="Gardenservice"
              placeholder="Your answer"
              autoComplete="off"
              onChange={handleInput}
            />

            {errors.Gardenservice && (
              <span className="text-red-500 text-sm">
                {errors.Gardenservice}
              </span>
            )}
          </div>

          <input
            type="submit"
            value="submit"
            className="uppercase bg-[#673ab7] text-white px-4 py-2 my-2 mx-10 cursor-pointer"
          />
        </form>
      </div>
    </>
  );
};

export default Forms;
