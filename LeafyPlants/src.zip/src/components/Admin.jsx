import React, { useState } from 'react'
import { Link } from "react-router-dom";
import {useNavigate} from "react-router-dom"

import Validation from './LoginValidation';
import axios from 'axios';



const Admin = () => {
  const navigate = useNavigate();
  const [values,setValues]=useState({
    email:'',
    password:'',
  })
  const [errors,setErrors]=useState({})
  const handleInput=(event)=>{
    setValues(prev=>({...prev,[event.target.name]:[event.target.value]}))
  }
  const handleSubmit =(event)=>{
    event.preventDefault();
    setErrors(Validation(values))
    if ( errors.email==="" && errors.password==="") {
      axios.post('http://localhost:8080/login', values)
        .then(res => {
          if(res.data === 'success'){

            navigate('/');
          }else{
            alert("no record existed");
          }
          // console.log(res);
        })
        .catch(err => {
          console.error(err)});
    }
  }
  return (
    <>
      <div className='flex flex-col m-auto justify-center bg-[#fefefe] items-center border-2 w-96 h-2/5 my-14  text-xl rounded-xl font-sans'>

                   <h1 className='my-6 text-4xl text-green-500 font-bold'>Admin Login</h1>
                   <form action="" className='flex flex-col' onSubmit={handleSubmit}>
                <input type="email" placeholder='Admin
                ' onChange={handleInput} name='email' className='w-80 h-10 my-4 px-4 rounded-md' />
                {errors.email && <span className='text-red-500 text-sm'>{errors.email}</span>}
                <input type="password" placeholder='password' onChange={handleInput} name='password' className='w-80 h-10 my-4 px-4 rounded-md' />
                {errors.password && <span className='text-red-500 text-sm'>{errors.password}</span>}
                <input type="submit"   className='uppercase bg-[#149253] rounded-md w-80 h-10 text-white my-4 cursor-pointer' value="Sing in"/>
            </form>
            
           
      </div>
    </>
  )
}

export default Admin

