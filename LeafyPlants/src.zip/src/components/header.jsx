import React from 'react'
import { NavLink } from 'react-router-dom';

const Header = () => {
  return (
    <header className='px-12 py-3  grid sm:grid-cols-2 md:grid-cols-3 bg-[#0f4c36] text-white font-semibold'>
        <NavLink to='/Working' className='uppercase px-10  '>Vendor Register</NavLink>
        <NavLink to='/Working' className='uppercase px-10'>Free Shipping above ₹499 </NavLink>
        <NavLink to='/Working'className='uppercase px-10'>relavant information</NavLink>
        {/* <NavLink to='/Userpage'>Franchise Enquiry</NavLink> */}
    </header>
  )
}

export default Header;