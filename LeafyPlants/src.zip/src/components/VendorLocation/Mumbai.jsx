import React from 'react'

const Mumbai = () => {
  return (
    <>
      <div>Mumbai</div>
    </>
  )
}
export default Mumbai;
