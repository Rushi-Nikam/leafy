function FormValidation(values) {
    let errors = {};

    const email_pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (values.name === undefined || values.name === "") {
        errors.name = "Name should not be empty";
    } else {
        errors.username = "";
    }
    if (values.email === undefined || values.email === "") {
        errors.email = "Email should not be empty";
    } else if (!email_pattern.test(values.email)) {
        errors.email = "Email format is incorrect";
    } else {
        errors.email = "";
    }
    if (values.number === undefined || values.number === "") {
        errors.number = "Email should not be empty";
    }  else {
        errors.number = "";
    }
    if (values.Address === undefined || values.Address === "") {
        errors.Address = "Address should not be emp ty";
    }  else {
        errors.Address = "";
    }
    if (values.Gardenservice === undefined || values.Gardenservice === "") {
        errors.Gardenservice = "Gardenservice should not be empty";
    }  else {
        errors.Gardenservice = "";
    }

    return errors;
}

export default FormValidation;