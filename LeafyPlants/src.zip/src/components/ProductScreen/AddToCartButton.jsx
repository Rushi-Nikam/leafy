import React from 'react';

const AddToCartButton = ({ item, handleAddToCart }) => {
  const handleClick = () => {
    handleAddToCart(item);
  };

  return (
    <button onClick={handleClick} className='uppercase bg-green-700 text-white p-4'>
      Add to cart
    </button>
  );
};

export default AddToCartButton;
