import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

import AddToCartButton from './AddToCartButton';
import data from '../Data/data';
import data2 from '../Data/data2';

const SingleProduct = () => {
  const { id } = useParams(); 
  const [product, setProduct] = useState(null);

  useEffect(() => {
    const fetchProduct = () => {
      const selectedProduct = data.find(item => item.id === id);
      if(selectedProduct){
        
        setProduct(selectedProduct);
      }else {
        const selectedProduct = data2.find(item => item.id === id);
        if(selectedProduct){

          setProduct(selectedProduct);
        }
      }
    };

    fetchProduct();
  }, [id]);

  const handleAddToCart = (item) => {
    // Implement the logic to add the item to the cart
    console.log('Item added to cart:', item);
  };

  return (
    <div>
      {product ? (
        <div>
          <div className='flex gap-1 text-xl my-2 mx-24 text-green-500'>
            <Link to={`/`}><span>Home</span>  /  </Link> <span>{product.title}</span>
          </div>
          <div className='grid grid-cols-2 gap-4 my-10 w-full  font-serif'>
            <div className='w-full h-lvh mx-24'>
              <img className='h-5/6' src={product.image} alt={product.title}/>
            </div>
            <div className='mx-12 my-10'>
              <h2 className='font-bold text-4xl'>{product.title}</h2>
              <p className='text-2xl'>Description: {product.description}</p>
              {product?.quantity <= 10 ? 
              <p>Product quantity minimum. Order now</p>  
              :
              null
            }
              <p className='text-2xl text-green-500'>Price: ₹{product.price}</p>
             
              <AddToCartButton item={product} handleAddToCart={handleAddToCart} /> {/* Pass product as item */}
            </div>
          </div>
        </div>
      ) : (
        <p>Product not found</p>
      )}
    </div>
  );
};

export default SingleProduct;
